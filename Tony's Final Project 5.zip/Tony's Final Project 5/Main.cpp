/*
Main.cpp
Class that tests and analyze sorting algorithms.
Author: Tony Nguyen
Date Created: 4/17/2018
Version: 1.0
*/

#include <iostream>
#include <windows.h>
#include <time.h>
using namespace std;

//---------- Insertion Sort Algorithm ----------//

/*
Insertion sort algorithm.
@param data Array of values to sort.
@param size Size of array.
*/
void insertionSort(int *data, int size)
{
	int j, temp;
	for (int i = 0; i < size; i++)
	{
		j = i;
		while (j > 0 && data[j - 1] > data[j])
		{
			temp = data[j];
			data[j] = data[j - 1];
			data[j - 1] = temp;
			j--;
		}
	}
}

//---------- Selection Sort Algorithm ----------//

/*
Selection sort algorithm.
@param data Array of values to sort.
@param size Size of array.
*/
void selectionSort(int *data, int size)
{
	for (int i = 0; i < size - 1; i++)
	{
		int iMin = i;
		for (int j = i + 1; j < size; j++)
		{
			if (data[j] < data[iMin])
			{
				iMin = j;
			}
		}
		int temp = data[i];
		data[i] = data[iMin];
		data[iMin] = temp;
	}
}

//---------- Heap Sort Algorithm ----------//

/*
Sort list.
@param arr List to sort.
@param n Start index.
@param i Size of list.
*/
void heapify(int *data, int n, int i)
{
	int largest = i;
	int l = 2 * i + 1;
	int r = 2 * i + 2;

	// Case if left child is larger than the max.
	if (l < n && data[l] > data[largest])
	{
		largest = l;
	}

	// Case if right child is larger than the max.
	if (r < n && data[r] > data[largest])
	{
		largest = r;
	}

	// Largest is not the root.
	if (largest != i)
	{
		// Swap the values.
		swap(data[i], data[largest]);

		// Call heapify on the subtree.
		heapify(data, n, largest);
	}
}

/*
Building the heap of values.
@param arr List to sort.
@param n Index to start from.
*/
void heapSort(int *data, int n)
{
	// Make the heap and rearrange it if needed.
	for (int i = n / 2 - 1; i >= 0; i--)
	{
		// Call heapify to make changes if needed.
		heapify(data, n, i);
	}

	// Remove one element at a time from heap.
	for (int i = n - 1; i >= 0; i--)
	{
		// Swap root to the end.
		swap(data[0], data[i]);

		// Call heapify on the new heap.
		heapify(data, i, 0);
	}
}

//---------- Quick Sort Algorithm ----------//

/*
This method sorts through array given with the start and end index.
This sorts using a pivot and all values less than pivot will move to the left.
After all values less than pivot moves to the left then swap the current partition with pivot and return.
@param array List to sort.
@param start First index.
@param end Last index.
*/
int partition(int *array, int start, int end)
{
	// Pivot is always the last element in the list.
	int pivot = array[end];
	// Start partition index as start initially.
	int partitionIndex = start;

	for (int i = start; i < end; i++)
	{
		// If element is less or equal to pivot then go in here.
		if (array[i] <= pivot)
		{
			// Swap if element is less than pivot.
			swap(array[i], array[partitionIndex]);
			// Move on to the next index to test.
			partitionIndex++;
		}
	}
	// After all values less than pivot are to the left then swap the current partition index with the pivot at the end.
	swap(array[partitionIndex], array[end]);
	// Return partition index.
	return partitionIndex;
}

/*
This method uses recursion and calls to partition to sort the list.
@param array List to sort.
@param start First index.
@param end Last index.
*/
void quickSort(int *array, int start, int end)
{
	// Base case for recursion. If end equals to or is less than start then break recursion.
	if (start < end)
	{
		// Calling partition to sort list.
		int pIndex = partition(array, start, end);
		// Sort the numbers to the left of pivot which is less than pivot.
		quickSort(array, start, pIndex - 1);
		// Sort the numbers to the right of pivot which is greater than pivot.
		quickSort(array, pIndex + 1, end);
	}
}


//---------- Main Method. ----------//
LARGE_INTEGER start, stop;
int* A;
int* B;
// Set of sizes 1000 to 5000 to test.
int X[] = { 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500 };

int main()
{
	// Create the test array size. Array A stays unsorted. We are going to test the workings of our sorting algorithms.
	int testSize = 30;
	A = new int[testSize];

	// Now fill A up with random values.
	for (int i = 0; i < testSize; i++)
	{
		//A[i] = (rand() % testSize) + 1;
		A[i] = rand();
	}

	//---------- Sort 1: Insertion Sort. ----------//
	// Copy A into B.
	B = new int[testSize];
	for (int i = 0; i < testSize; i++)
	{
		B[i] = A[i];
	}

	insertionSort(B, testSize);

	// A sample size of testSize.
	cout << "Insertion Sort:" << endl;
	for (int i = 0; i < testSize; i++)
	{
		cout << B[i] << " ";
	}
	cout << endl << endl;

	//---------- Sort 2: Selection Sort. ----------//
	delete[] B;
	// Copy A into B.
	B = new int[testSize];
	for (int i = 0; i < testSize; i++)
	{
		B[i] = A[i];
	}

	selectionSort(B, testSize);

	// A sample of testSize.
	cout << "Selection Sort:" << endl;
	for (int i = 0; i < testSize; i++)
	{
		cout << B[i] << " ";
	}
	cout << endl << endl;

	//---------- Sort 3: Heap Sort. ----------//
	delete[] B;
	// Copy A into B.
	B = new int[testSize];
	for (int i = 0; i < testSize; i++)
	{
		B[i] = A[i];
	}
	
	heapSort(B, testSize);

	// Sample of testSize.
	cout << "Heap Sort:" << endl;
	for (int i = 0; i < testSize; i++)
	{
		cout << B[i] << " ";
	}
	cout << endl << endl;

	//---------- Sort 4: Quick Sort. ----------//
	delete[] B;
	// Copy A into B.
	B = new int[testSize];
	for (int i = 0; i < testSize; i++)
	{
		B[i] = A[i];
	}

	quickSort(B, 0, testSize - 1);

	// A sample of testSize.
	cout << "Quick Sort:" << endl;
	for (int i = 0; i < testSize; i++)
	{
		cout << B[i] << " ";
	}
	cout << endl << endl;

	delete[] A;
	delete[] B;
	//----------Now here we will be using 10 sets of sizes and test out the sorting time complexity----------//
	int insertionSortTick = 0;
	int selectionSortTick = 0;
	int heapSortTick = 0;
	int quickSortTick = 0;
	int numberOfSets = 10;
	for (int i = 0; i < numberOfSets; i++)
	{
		// Set arrays A and B to have different sizes of 1000, 2000, 3000, 4000, 5000, etc.
		A = new int[X[i]];
		B = new int[X[i]];

		cout << "//--------------------//" << endl;
		cout << "Test Sorting on Size " << X[i] << endl << endl;

		for (int j = 0; j < numberOfSets; j++)
		{
			cout << "--------------------" << endl;
			cout << "Set " << j + 1 << endl << endl;

			// Fill up array A with X[i] random numbers.
			for (int k = 0; k < X[i]; k++)
			{
				A[k] = rand();
			}
			
			// Copy A into B.
			for (int k = 0; k < X[i]; k++)
			{
				B[k] = A[k];
			}

			//----------Time for Insertion Sort----------//

			// Output sorted insertion sort.
			cout << "Insertion Sort Unsorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			// Find and keep track of time.
			QueryPerformanceCounter(&start);
			insertionSort(B, X[i]);
			QueryPerformanceCounter(&stop);
			insertionSortTick += (int) stop.QuadPart - start.QuadPart;

			// Output sorted insertion sort.
			cout << "Insertion Sort Sorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			//----------Time for Selection Sort----------//
			delete[] B;
			// Copy A into B.
			B = new int[X[i]];
			for (int k = 0; k < X[i]; k++)
			{
				B[k] = A[k];
			}

			// Output unsorted selection sort.
			cout << "Selection Sort Unsorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			// Find and keep track of time.
			QueryPerformanceCounter(&start);
			selectionSort(B, X[i]);
			QueryPerformanceCounter(&stop);
			selectionSortTick += (int) stop.QuadPart - start.QuadPart;

			// Output sorted selection sort.
			cout << "Selection Sort Sorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			//----------Time for Heap Sort----------//
			delete[] B;
			// Copy A into B.
			B = new int[X[i]];
			for (int k = 0; k < X[i]; k++)
			{
				B[k] = A[k];
			}

			// Output unsorted heap sort.
			cout << "Heap Sort Unsorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			// Find and keep track of time.
			QueryPerformanceCounter(&start);
			heapSort(B, X[i]);
			QueryPerformanceCounter(&stop);
			heapSortTick += (int) stop.QuadPart - start.QuadPart;

			// Output sorted heap sort.
			cout << "Heap Sort Sorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			//----------Time for Quick Sort----------//
			delete[] B;
			// Copy A into B.
			B = new int[X[i]];
			for (int k = 0; k < X[i]; k++)
			{
				B[k] = A[k];
			}
			
			// Output unsorted quick sort.
			cout << "Quick Sort Unsorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;

			// Find and keep track of time.
			QueryPerformanceCounter(&start);
			quickSort(B, 0, X[i] - 1);
			QueryPerformanceCounter(&stop);
			quickSortTick += (int) stop.QuadPart - start.QuadPart;
			
			// Output sorted quick sort.
			cout << "Quick Sort Sorted:" << endl;
			for (int i = 0; i < 10; i++)
			{
				cout << B[i] << " ";
			}
			cout << endl << endl;
		}

		// Find the average.
		cout << "Average ticks for Insertion Sort on size " << X[i] << ": " << (insertionSortTick / numberOfSets) << ".\n";
		cout << "Average ticks for Selection Sort on size " << X[i] << ": " << (selectionSortTick / numberOfSets) << ".\n";
		cout << "Average ticks for Heap Sort on size " << X[i] << ": " << (heapSortTick / numberOfSets) << ".\n";
		cout << "Average ticks for Quick Sort on size " << X[i] << ": " << (quickSortTick / numberOfSets) << ".\n";
		cout << endl;

		// Reset value to calculate for the next set.
		insertionSortTick = 0;
		selectionSortTick = 0;
		heapSortTick = 0;
		quickSortTick = 0;

		delete[] A;
		delete[] B;
	}

	return 0;
}