/*
SortedArray.h
Class definition for SortedArray.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
using namespace std;

template <class DT>
class SortedArray
{
protected:
	// The pointer array with DT in it.
	DT* paObject;
	// Size of sorted array.
	int size;
	// Keep track of number of items in sorted array.
	int sizeCounter;
	//void copy(const SortedArray<DT>& ac);
public:
	// Default constructor.
	SortedArray();
	// Second constructor that takes in size.
	SortedArray(int n);
	// Third constructor that takes in size and a value.
	SortedArray(int n, const DT& val);
	// Copy constructor.
	SortedArray(const SortedArray<DT>& ac);

	// Look for a value using binary search.
	int find(DT& lookFor);
	// Insert new value.
	int insert(DT& newElement);
	// Remove value.
	int remove(DT& oldElement);
	// Split sorted array and returns the splitted part.
	SortedArray<DT>& split(int i);
	// Copies P sorted array to this sorted array. P would be deleted.
	SortedArray<DT>& join(SortedArray<DT>& P);

	// Get the size of sorted array.
	int getSize() const;
	// Gets element at position k.
	DT& operator[] (int k);
	// Deconstructor to free up memory.
	virtual ~SortedArray();
};

/*
Default constructor that initializes everything.
*/
template <class DT>
SortedArray<DT>::SortedArray()
{
	size = 0;
	sizeCounter = 0;
	paObject = NULL;
}

/*
Second constructor that takes in size.
@param n Size for sorted array.
*/
template <class DT>
SortedArray<DT>::SortedArray(int n)
{
	size = n;
	sizeCounter = 0;
	// Create new space for paObject.
	paObject = new DT[size];
	// Set everything to 0 initially.
	for (int i = 0; i < size; i++)
	{
		paObject[i] = 0;
	}
}

/*
Third constructor.
@param n Size of sorted array.
@param val New object to add in.
*/
template <class DT>
SortedArray<DT>::SortedArray(int n, const DT& val)
{
	size = n;
	// Create new space for paObject.
	paObject = new DT[size + 1];
	// Set everything to 0 initially.
	for (int i = 0; i < size; i++)
	{
		paObject[i] = 0;
	}
	// Adding val into paObject.
	paObject[size] = val;
	sizeCounter = size;
	sizeCounter++;
	size++;
}

/*
Look for a value using binary search.
@param lookFor The thing we are looking for.
@return mid which is index lookFor is located at or -1 if can't find number.
*/
template <class DT>
int SortedArray<DT>::find(DT& lookFor)
{
	int low = 0;
	int high = size - 1;
	
	// Execute while low is not higher than high meaning out of search space.
	while (low <= high)
	{
		int mid = (low + high) / 2;
		
		// If searchValue equals mid.
		if (lookFor == paObject[mid])
		{
			return mid;
		}
		// Else if searchValue is greater than mid.
		else if (lookFor > paObject[mid])
		{
			low = mid + 1;
		}
		// Else searchValue is less than mid.
		else
		{
			high = mid - 1;
		}
	}
	// If we can't find number.
	return -1;
}

/*
Insert new value in order from least to greatest.
@param newElement Item to be inserted.
@return someNumber or -1 if there is no room to insert into array.
*/
template <class DT>
int SortedArray<DT>::insert(DT& newElement)
{
	// Creating new paObject to insert new element into.
	DT newPaObject = new DT[size + 1];

	// Checks if the array is full or not. If so then return -1.
	if (sizeCounter == size)
	{
		return -1;
	}

	// Do binary search to check if number isn't already in the array and to find position for it to insert into.
	if (find(newElement) != -1)
	{
		// Use binary search to locate numbers least than newElement and numbers greater than newElement to find index.


		// Increment counter to keep track of number of items.
		sizeCounter++;
		// Increase size.
		size++;
	}
}

/*
Removes value.
@param oldElement Item to be removed.
@return someNumber or -1 if number is not in the array.
*/
template <class DT>
int SortedArray<DT>::remove(DT& oldElement)
{
	// Creating new paObject to insert new element into.
	DT* newPaObject = new DT[size - 1];

	// Checks if number is present in the array. If not then return -1.
	if (find(oldElement) == -1)
	{
		return -1;
	}
	else
	{
		// Shift elements to the left by one and return the number of items in array.
		for (int i = 0; i < size; i++)
		{
			if (paObject[i] != oldElement)
			{
				newPaObject[i] = paObject[i];
			}
		}

		// Delete old array.
		delete[] paObject;
		// Make paObject equal to new paObject.
		paObject = newPaObject;

		// Decrease item counter.
		sizeCounter--;
		// Decrease size.
		size--;
		return sizeCounter;
	}
}

/*
Split sorted array and returns the splitted part.
@param i Index to split the array at.
@return a new sorted array.
*/
template <class DT>
SortedArray<DT>& SortedArray<DT>::split(int i)
{
	// Split the array all the way to index i.

}

/*
Copies P sorted array to this sorted array. P would be deleted.
@param P The array to join together with another array.
@return The whole new array.
*/
template <class DT>
SortedArray<DT>& SortedArray<DT>::join(SortedArray<DT>& P)
{
	// Making sure array P is sorted.

	// Copy P over to this array using overloaded = for deep copy.
	for (int i = 0; i < size; i++)
	{
		
	}

	// Delete array P.
	delete[] P;
}

/*
Get size of sorted array.
@return size.
*/
template <class DT>
int SortedArray<DT>::getSize() const 
{
	return size;
}

/*
Gets the object at position k.
@param k Position.
@return paObject[k].
*/
template <class DT>
DT& SortedArray<DT>::operator[] (int k)
{
	sizeCounter++;
	return paObject[k];
}

/*
Deconstructor that frees up memory in heap.
*/
template <class DT>
SortedArray<DT>::~SortedArray()
{
	paObject = NULL;
	delete paObject;
	size = 0;
}