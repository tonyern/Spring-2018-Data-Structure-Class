/*
SortedArray.h
Class definition for SortedArray.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
using namespace std;

template <class DT>
class SortedArray
{
protected:
	// The pointer array with DT in it.
	DT* paObject;
	// Size of sorted array.
	int size;
	// Keep track of number of items in sorted array.
	int sizeCounter;
public:
	// Default constructor.
	SortedArray();
	// Second constructor that takes in size.
	SortedArray(int n);
	// Copy constructor.
	SortedArray(const SortedArray<DT>& ac);

	// Look for a value using binary search.
	int find(DT& lookFor);
	// Insert new value.
	int insert(DT& newElement);
	// Remove value.
	int remove(DT& oldElement);
	// Split sorted array and returns the splitted part.
	DT* split(int i);
	// Copies P sorted array to this sorted array. P would be deleted.
	void join(SortedArray<DT>& P);
	// Simple sorting algorithm to find where to insert newElement at.
	void insertionSort(DT* array, int size);

	// Display paObject sorted array.
	void display();
	// Get the size of sorted array.
	int getSize() const;
	// Get the current number of items in sorted array.
	int getNumberOfItems();
	// Gets element at position k.
	DT& operator[] (int k);
	// Deconstructor to free up memory.
	virtual ~SortedArray();
};

/*
Default constructor that initializes everything.
*/
template <class DT>
SortedArray<DT>::SortedArray()
{
	size = 0;
	sizeCounter = 0;
	paObject = NULL;
}

/*
Second constructor that takes in size.
@param n Size for sorted array.
*/
template <class DT>
SortedArray<DT>::SortedArray(int n)
{
	size = n;
	sizeCounter = 0;
	// Create new space for paObject.
	paObject = new DT[size];
	// Set everything to 0 initially.
	for (int i = 0; i < size; i++)
	{
		paObject[i] = 0;
	}
}

/*
Copy constructor.
@param ac New SortedArray object we want to copy this object into ac.
*/
template <class DT>
SortedArray<DT>::SortedArray(const SortedArray<DT>& ac)
{
	this->paObject = ac.paObject;

	// Copy elements over.
	for (int i = 0; i < ac.size; i++)
	{
		this->paObject[i] = ac.paObject[i];
	}
}

/*
Look for a value using binary search.
@param lookFor The thing we are looking for.
@return mid which is index lookFor is located at or -1 if can't find number.
*/
template <class DT>
int SortedArray<DT>::find(DT& lookFor)
{
	int low = 0;
	int high = size - 1;

	// Execute while low is not higher than high meaning out of search space.
	while (low <= high)
	{
		int mid = (low + high) / 2;

		// If searchValue equals mid.
		if (lookFor == paObject[mid])
		{
			return mid;
		}
		// Else if searchValue is greater than mid.
		else if (lookFor > paObject[mid])
		{
			low = mid + 1;
		}
		// Else searchValue is less than mid.
		else
		{
			high = mid - 1;
		}
	}
	// If we can't find number.
	return -1;
}

/*
Insert new value in order from least to greatest.
@param newElement Item to be inserted.
@return someNumber or -1 if there is no room to insert into array.
*/
template <class DT>
int SortedArray<DT>::insert(DT& newElement)
{
	// Creating new paObject to insert new element into.
	DT* newPaObject = new DT[size];

	// Checks if the array is full or not. If so then return -1.
	if (sizeCounter == size)
	{
		return -1;
	}

	// Do binary search to check if number isn't already in the array and to find position for it to insert into.
	int newElementIndex = find(newElement);
	// Where the element is stored.
	int elementIndex = 0;
	if (newElementIndex == -1)
	{
		// Add old array into new array.
		for (int i = 0; i < size; i++)
		{
			newPaObject[i] = paObject[i];
		}
		newPaObject[size - 1] = newElement;
		// Increment counter to keep track of number of items.
		sizeCounter++;

		// Sort the newElement into correct position.
		insertionSort(newPaObject, size);

		// Look for where the array is newElement located.
		for (int i = 0; i < size; i++)
		{
			if (newPaObject[i] == newElement)
			{
				elementIndex = i;
			}
		}

		// Delete old array.
		delete[] paObject;
		// Set new paObject.
		paObject = newPaObject;

		// Return the index new element is stored in.
		return elementIndex;
	}
}

/*
Just a simple sorting algorithm when adding items to the list.
*/
template <class DT>
void SortedArray<DT>::insertionSort(DT* array, int size)
{
	int j;
	DT temp;

	// i equals second number in the list and would loop all the way to end of list.
	for (int i = 1; i < size; i++)
	{
		// Make j equal to i.
		j = i;
		// While j is greater than 0 and left side number is greater than right side number.
		while (j > 0 && array[j - 1] > array[j])
		{
			// Size the lower number in temp.
			temp = array[j];
			// Now make the lower number equal the higher number.
			array[j] = array[j - 1];
			// Now make higher number equal to lower number.
			array[j - 1] = temp;
			// Decrease j.
			j--;
		}
	}
}

/*
Removes value.
@param oldElement Item to be removed.
@return someNumber or -1 if number is not in the array.
*/
template <class DT>
int SortedArray<DT>::remove(DT& oldElement)
{
	// Creating new paObject to insert new element into.
	DT* newPaObject = new DT[size];

	// Checks if number is present in the array. If not then return -1.
	int oldElementIndex = find(oldElement);
	if (oldElementIndex == -1)
	{
		return -1;
	}
	else
	{
		// Shift elements to the left by one and return the number of items in array.
		for (int i = 0; i < oldElementIndex; i++)
		{
			newPaObject[i] = paObject[i];
		}
		for (int i = oldElementIndex; i < size; i++)
		{
			newPaObject[i] = paObject[i + 1];
		}

		// Delete old array.
		delete[] paObject;
		// Make paObject equal to new paObject.
		paObject = newPaObject;

		// Decrease item counter.
		sizeCounter--;
		return sizeCounter;
	}
}

/*
Split sorted array and returns the splitted part.
@param i Index to split the array at.
@return a new sorted array.
*/
template <class DT>
DT* SortedArray<DT>::split(int i)
{
	// Split the array all the way to index i.
	DT* tempArray = new DT[size - i];

	// Add stuff in old array to temp array until we hit index i.
	for (int j = 0; j < i; j++)
	{
		tempArray[j] = paObject[j];
	}
	// Set from index i to end of array to null.
	for (int j = i; j < size; j++)
	{
		paObject[j] = NULL;
		sizeCounter--;
	}

	// Adjust size accordingly.
	size = size - i;
	return tempArray;
}

/*
Copies P sorted array to this sorted array. P would be deleted.
@param P The array to join together with another array.
@return The whole new array.
*/
template <class DT>
void SortedArray<DT>::join(SortedArray<DT>& P)
{
	// New Joined Array to add into.
	int joinedArraySize = this->size + P.size;
	DT* newJoinedArray = new DT[joinedArraySize];

	int lastIndex = 0;
	// Add stuff in old array to temp array.
	for (int i = 0; i < this->size; i++)
	{
		newJoinedArray[i] = paObject[i];
		// Keep track of last index so we know where to merge P array at.
		if (i == this->size - 1)
		{
			lastIndex = i;
		}
	}

	// Adding P array into new joined array.
	int j = 0;
	for (int i = lastIndex + 1; i < joinedArraySize; i++)
	{
		newJoinedArray[i] = P.paObject[j];
		j++;

		// Increment size and size counter.
		sizeCounter++;
		size++;
	}

	// Sort the array.
	insertionSort(newJoinedArray, joinedArraySize);

	// Delete old paObject and P array.
	delete[] paObject;
	P = NULL;

	// Change this paObject to newJoinedArray.
	paObject = newJoinedArray;
}

/*
Display sorted array.
*/
template <class DT>
void SortedArray<DT>::display()
{
	for (int i = 0; i < sizeCounter; i++)
	{
		cout << paObject[i] << " ";
	}
	cout << endl;
}

/*
Get size of sorted array.
@return size.
*/
template <class DT>
int SortedArray<DT>::getSize() const
{
	return size;
}

/*
Get the current number of items in the sorted array.
*/
template <class DT>
int SortedArray<DT>::getNumberOfItems()
{
	return sizeCounter;
}

/*
Gets the object at position k.
@param k Position.
@return paObject[k].
*/
template <class DT>
DT& SortedArray<DT>::operator[] (int k)
{
	sizeCounter++;
	return paObject[k];
}

/*
Deconstructor that frees up memory in heap.
*/
template <class DT>
SortedArray<DT>::~SortedArray()
{
	if (paObject != NULL)
	{
		for (int i = 0; i < sizeCounter; i++)
		{
			paObject[i] = NULL;
		}
		paObject = NULL;
		delete[] paObject;
		size = 0;
		sizeCounter = 0;
	}
}