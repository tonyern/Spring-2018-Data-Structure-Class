/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "LinkedSortedArrays.h"
#include "SortedArray.h"
using namespace std;

int main()
{
	// Testing second constructor.
	//SortedArray<int>* testSortedArray = new SortedArray<int>(5);
	//cout << "Size: " << testSortedArray->getSize() << endl;

	// Testing third constructor.
	int testFind = 10;
	SortedArray<int>* testSortedArray2 = new SortedArray<int>(5);
	(*testSortedArray2)[0] = 5;
	(*testSortedArray2)[1] = 9;
	(*testSortedArray2)[2] = 10;
	(*testSortedArray2)[3] = 15;
	(*testSortedArray2)[4] = 69;
	//cout << testSortedArray2->find(testFind) << endl;
	cout << "Number of items: " << (*testSortedArray2).remove(testFind) << endl;

	return 0;
}
