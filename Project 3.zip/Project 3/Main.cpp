/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	// LinkedList.
	LinkedSortedArrays<SortedArray<int>>* linked = new LinkedSortedArrays<SortedArray<int>>();

	// Testing third constructor.
	SortedArray<int>* testSortedArray2 = new SortedArray<int>(5);
	(*testSortedArray2)[0] = 5;
	(*testSortedArray2)[1] = 9;
	(*testSortedArray2)[2] = 10;
	(*testSortedArray2)[3] = 15;
	(*testSortedArray2)[4] = 69;
	
	return 0;
}
