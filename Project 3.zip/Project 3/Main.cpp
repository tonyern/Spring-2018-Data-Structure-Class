/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	// Testing third constructor.
	SortedArray<int>* testSortedArray2 = new SortedArray<int>(5);

	int value1 = 1;
	int value2 = 12;
	int value3 = 35;
	int value4 = 69;
	int value5 = 81;
	(*testSortedArray2).insert(value1);
	(*testSortedArray2).insert(value2);
	(*testSortedArray2).insert(value3);
	(*testSortedArray2).insert(value4);
	(*testSortedArray2).insert(value5);
	(*testSortedArray2).display();
	
	// LinkedList.
	//LinkedSortedArrays<SortedArray<int>>* linked = new LinkedSortedArrays<SortedArray<int>>(5);
	//(*linked).insert(*testSortedArray2);

	return 0;
}
