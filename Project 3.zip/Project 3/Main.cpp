/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	// Size limit of array.
	int maxArraySize;
	LinkedSortedArrays<int>* linkedArrays;
	
	// Read in the max array size and create the LinkedSortedArrays object.
	cin >> maxArraySize;
	linkedArrays = new LinkedSortedArrays<int>(maxArraySize);

	return 0;
}
