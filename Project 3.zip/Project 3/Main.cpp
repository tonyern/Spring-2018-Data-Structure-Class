/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	SortedArray<int>* testSortedArray = new SortedArray<int>(5);
	int value1 = 5;
	int value2 = 10;
	int value3 = 69;
	int value4 = 70;
	int value5 = 88;
	(*testSortedArray).insert(value1);
	(*testSortedArray).insert(value2);
	(*testSortedArray).insert(value3);
	(*testSortedArray).insert(value4);
	(*testSortedArray).insert(value5);
	(*testSortedArray).remove(value3);
	(*testSortedArray).display();

	// LinkedList.
	LinkedSortedArrays<int>* linked = new LinkedSortedArrays<int>();
	(*linked).find(value3);
	//(*linked).insert(value3);
	//cout << *linked;

	// Size limit of array.
	//int maxArraySize;
	//LinkedSortedArrays<SortedArray<int>>* linkedArrays;
	
	// Read in the max array size and create the LinkedSortedArrays object.
	//cin >> maxArraySize;
	//linkedArrays = new LinkedSortedArrays<SortedArray<int>>(maxArraySize);

	return 0;
}
