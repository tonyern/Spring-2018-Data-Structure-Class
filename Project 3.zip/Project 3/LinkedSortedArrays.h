/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "SortedArray.h"
using namespace std;

template <class DT>
class LinkedSortedArrays
{
	friend ostream& operator<< (ostream& output, const LinkedSortedArrays<DT>& ll)
	{
		for (auto it = ll.nameIT.begin(); it != ll.nameIT.end(); it++)
		{
			output << *ll.it << " ";
		}
		cout << endl;

		return output;
	}
protected:
	// LinkedList to store sorted arrays in.
	list<SortedArray<DT>> nameIT;
	// Max size of array in Sorted Array.
	int ArraySizeFactor;
	// Length of LinkedList.
	int length;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Overloaded constructor with max size for sorted arrays.
	LinkedSortedArrays(int arraySize);
	// Copy constructor.
	LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other);
	
	// Find the number.
	int find(const DT& lookFor);
	// Insert number into an array.
	int insert(const DT& newOne);
	// Remove number from an array.
	int remove(const DT& X);
	
	// Get max size of array.
	int getArraySizeFactor() const;
	// Get the current number of nodes in LinkedList.
	int getLength();
	// Deconstructor.
	virtual ~LinkedSortedArrays();
};

/*
Default constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays()
{
	ArraySizeFactor = 0;
	length = 0;
}

/*
Overloaded constructor that determines max size for all sorted arrays.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(int arraySize)
{	
	// Read data from file.
	char c = '0';
	// Helps convert character to integer.
	int iNum;
	int fNum;
	for (int i = 100; i != 0; i--)
	{
		cin.get(c);
		cout << c;
		switch (c)
		{
		case 'I':
			cin.get(c);
			cin.get(c);
			iNum = c - '0';
			cout << "Insert Number: " << iNum + 1 << endl;
			//insert(c);
			break;
		case 'R':
			cin.get(c);
			cin.get(c);
			iNum = c - '0';
			cout << "Remove Number: " << c << endl;
			//remove(atoi(c));
			break;
		case 'F':
			cin.get(c);
			cin.get(c);
			fNum = c - '0';
			cout << "Find Number: " << c << endl;
			cout << "Added Find Number: " << c + 1 << endl;
			//find(atoi(c));
			break;
		case 'O':
			cin.get(c);
			cout << c << endl;
			//display();
			break;
		}
	}

	ArraySizeFactor = arraySize;
	length = 0;
}

/*
Copy constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other)
{

}

/*
This method finds item user is looking for by iterating through the LinkedList.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
template <class DT>
int LinkedSortedArrays<DT>::find(const DT& lookFor)
{
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& sa = *iter;

		// If lookFor is not greater than max then execute find.
		if (!(sa.getMax() < lookFor) && !(lookFor < sa.getMin()))
		{
			int itemIndex = sa.find(lookFor);
			return itemIndex;
		}
		// If lookFor is smaller than the min or bigger than max then return -1.
		if (sa.getMin() > lookFor || lookFor > sa.getMax())
		{
			return -1;
		}
	}
}


/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
template <class DT>
int LinkedSortedArrays<DT>::insert(const DT& newOne)
{
	/*// Check if list is empty or number is already in list.

	auto iter = nameIT.begin();
	iter++;
	int i = 0;

	for (; iter != nameIT.end() && !(iter->getMin() > newOne); iter++; i++);
	iter--;

	// Case C: Returns -1 if array is full and we apply split operation.
	int result = iter->insert(newOne);
	if (result == -1)
	{
		auto iter2 = iter;
		iter2++;

		SortedArray<DT>& temp = iter->split(ArraySizeFactor / 2);

		iter2 = nameIT.insert(iter2, temp);
		delete &temp;
	}*/

	int i = 0;
	for (auto it = nameIT.begin(); it != nameIT.end(); it++, i++)
	{
		SortedArray<DT>& temp = *it;
		temp.insert(newOne);

		//int findIndex = find(newOne);
		// Case A: Check if element is already in our data structure. Any number not -1 is already in the list.
		//if (findIndex != -1)
		//{
		//	return -1;
		//}
		// Case B: Find an array with space where newOne will be inserted.
		//else if (findIndex == -1)
		//{
		//	temp.getMax();
		//	// Keep track of the number of arrays in list.
		//	length++;
		//}
		// Case C: Insert on SortedArray and if it returns -1 we will split SortedArray. The splitted arrays will still point to each other. 
		// -1 Means array is full.
		//else
		//{
			// This splits the array and thus creating another node.
			//if ((*it).insert(newOne) == -1)
			//{
			//	it->split(ArraySizeFactor / 2);
			//}

			// Keep track of the number of arrays in list.
			//length++;
			//}
		//}
	}
}

/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
template <class DT>
int LinkedSortedArrays<DT>::remove(const DT& X)
{
	// Make sure X exists before deleting.
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++)
	{
		SortedArray<DT>& temp = *iter;

		if (temp.find(X) != -1)
		{
			temp.remove(X);
		}
	}
}

/*
Get the max size of array.
@return ArraySizeFactor
*/
template <class DT>
int LinkedSortedArrays<DT>::getArraySizeFactor() const
{
	return ArraySizeFactor;
}

/*
Get the current number of nodes in the LinkedList.
@return length.
*/
template <class DT>
int LinkedSortedArrays<DT>::getLength()
{
	return length;
}

/*
Deconstructor.
*/
template <class DT>
LinkedSortedArrays<DT>::~LinkedSortedArrays()
{
	//if (nameIT != NULL)
	//{
	//	nameIT.clear();
	//	nameIT.~list();
	//}
}