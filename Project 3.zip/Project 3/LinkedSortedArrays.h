/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

//#include <iostream>
//#include <list>
//using namespace std;

/*template <class DT>
class LinkedSortedArrays
{
protected:
	list<SortedArray<DT>> nameIT;
	// Max size of array.
	int ArraySizeFactor;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Find the item using binary search.
	int find(const DT& lookFor);
	int insert(const DT& newOne);
	int remove(const DT& X);
	// Will have others.

	// Deconstructor.
	virtual ~LinkedSortedArrays();
};*/

/*
Default constructor.
*/
/*template <class DT>
LinkedSortedArrays::LinkedSortedArrays()
{
	nameIT = NULL;
	ArraySizeFactor = 0;
}
*/
/*
This method finds item user is looking for by using binary search.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
/*template <class DT>
LinkedSortedArrays::find(const DT& lookFor)
{

}
*/
/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
/*template <class DT>
int LinkedSortedArrays::insert(const DT& newOne)
{

}
*/
/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
/*template <class DT>
int LinkedSortedArrays::remove(const DT& X)
{

}
*/
/*
Deconstructor.
*/
/*template <class DT>
LinkedSortedArrays::~LinkedSortedArrays()
{

}*/