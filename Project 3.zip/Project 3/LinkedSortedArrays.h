/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "SortedArray.h"
using namespace std;

template <class DT>
class LinkedSortedArrays
{
protected:
	// Next item pointer.
	LinkedSortedArrays<SortedArray<DT>>* next;
	// Data inside the node.
	DT* data;
	// Max size of array in Sorted Array.
	int ArraySizeFactor;
	// Length of LinkedList.
	int length;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Overloaded constructor with max size for sorted arrays.
	LinkedSortedArrays(int ArraySizeFactor);
	// Copy constructor.
	LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other);
	
	// Find the item using binary search.
	int find(const DT& lookFor);
	int insert(const DT& newOne);
	int remove(const DT& X);
	
	// Display items in the list.
	void display();
	// Get max size of array.
	int getArraySizeFactor() const;
	// Get the current number of nodes in LinkedList.
	int getLength();
	// Deconstructor.
	virtual ~LinkedSortedArrays();
};

/*
Default constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays()
{
	next = NULL;
	data = NULL;
	ArraySizeFactor = 0;
	length = 0;
}

/*
Overloaded constructor that determines max size for all sorted arrays.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(int ArraySizeFactor)
{
	next = NULL;
	this->ArraySizeFactor = ArraySizeFactor;
	data = new DT[this->ArraySizeFactor];
	length = 0;
}

/*
This method finds item user is looking for by using binary search.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
template <class DT>
int LinkedSortedArrays<DT>::find(const DT& lookFor)
{

}


/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
template <class DT>
int LinkedSortedArrays<DT>::insert(const DT& newOne)
{
	// Keep track of the number of arrays in list.
	length++;
}

/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
template <class DT>
int LinkedSortedArrays<DT>::remove(const DT& X)
{

}

/*
Get the max size of array.
@return ArraySizeFactor
*/
template <class DT>
int LinkedSortedArrays<DT>::getArraySizeFactor() const
{
	return ArraySizeFactor;
}

/*
Get the current number of nodes in the LinkedList.
@return length.
*/
template <class DT>
int LinkedSortedArrays<DT>::getLength()
{
	return length;
}

/*
Deconstructor.
*/
template <class DT>
LinkedSortedArrays<DT>::~LinkedSortedArrays()
{

}