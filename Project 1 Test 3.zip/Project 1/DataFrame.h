/*
DataFrame.h
	This is the header class for the DataFrame.
	Created on: 1/22/2018
	Author: Tony Nguyen
	Version: 1.0
*/
#include <iostream>
using namespace std;

class DataFrame
{
protected:
	// The table that points to a location address that points to another location address.
	int** table;
	// The total number of rows.
	int noRows;
	// The total number of columns.
	int noCols;
	// Name of column in character.
	char** colNames;
	// Name of row in character.
	char** rowNames;
public:
	// Constructor that doesn't create anything.
	DataFrame();
	// Overloaded constructor to create the matrix of rows and columns.
	DataFrame(int rows, int cols);
	
	// Output for the program.
	void display();

	// Setters for row and column name.
	void setRowName(int row, char* name);
	void setColName(int col, char* name);

	// Get row and columns. Location.
	int* operator[] (int i); 

	// Getters for rows and columns names and number of them in table.
	char** getRowNames();
	char** getColNames();
	int getNumberRows();
	int getNumberCols();

	// Returns columns and I assume display them on screen.
	DataFrame* getColumns(int* columns, int cLen);
	// Returns rows and I assume display them on screen.
	DataFrame* getRows(int* rows, int rLen);
	// Returns rows and columns and display them on the screen.
	DataFrame* getRowsCols(int* rows, int rLen, int* cols, int cLen);

	// Deconstructor for trashcan.
	~DataFrame();
};