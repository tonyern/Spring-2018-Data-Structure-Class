/*
DataFrame.cpp
	This class implements the functions from the DataFrame's header.
	Created on: 1/22/2018
	Author: Tony Nguyen
	Version: 1.0
*/
#include <iostream>
#include "DataFrame.h"
using namespace std;

/*
Default constructor that doesn't create a matrix of rows and columns because of no specified row or column.
*/
DataFrame::DataFrame()
{
	noRows = 0;
	noCols = 0;
	rowNames = NULL;
	colNames = NULL;
	table = NULL;
}

/*
Overloaded constructor that takes in a row and column and creates the empty matrix.
	@param int rows Is the value used to construct the number of rows in table.
	@param int cols Is the value used to construct the number of columns in table.
*/
DataFrame::DataFrame(int rows, int cols)
{
	noRows = rows;
	noCols = cols;
	rowNames = new char*[noRows];
	colNames = new char*[noCols];
	// Initializing and creating the table of rows and columns.
	table = new int*[noRows];
	for (int i = 0; i < noRows; i++)
	{
		// For every row create a column using column length.
		table[i] = new int[noCols];
		// Set row names to be null initially.
		rowNames[i] = NULL;
		// Setting the table to hold zeros initially.
		for (int j = 0; j < noCols; j++)
		{
			table[i][j] = 0;
		}
	}
	// Setting column names to be null initially.
	for (int i = 0; i < noCols; i++)
	{
		colNames[i] = NULL;
	}
}

/*
This method displays the output from the matrix. This also displays all the row and column names.
*/
void DataFrame::display()
{
	// Display the column names.
	for (int i = 0; i < noCols; i++)
	{
		// In case column names is not set then print commas.
		if (colNames[i] == NULL)
		{
			if (i != noCols - 1)
			{
				cout << ",";
			}
			else
			{
				cout << endl;
			}
		}
		// For formatting.
		else if (i != noCols - 1)
		{
			cout << colNames[i] << ",";
		}
		else
		{
			cout << colNames[i] << endl;
		}
	}

	// Display the row names.
	for (int i = 0; i < noRows; i++)
	{
		// If case row names is not set then just print commas.
		if (rowNames[i] == NULL)
		{
			if (i != noRows - 1)
			{
				cout << ",";
			}
			else
			{
				cout << endl;
			}
		}
		// For formatting.
		else if (i != noRows - 1)
		{
			cout << rowNames[i] << ",";
		}
		else
		{
			cout << rowNames[i] << endl;
		}
	}

	// Going through each element in the matrix and outputting it.
	for (int i = 0; i < noRows; i++)
	{
		for (int j = 0; j < noCols; j++)
		{
			cout << table[i][j] << " ";
		}
		printf("\n");
	}
}

/*
This method sets the row name by adding it to the rowNames array.
	@param int row Is the row number to set to.
	@param char* name Is the name we want to set to a particular cell.
*/
void DataFrame::setRowName(int row, char* name)
{
	rowNames[row] = name;
}

/*
This method sets the column name by adding it to the colNames array.
	@param int col Is the column number to set to.
	@param char* name Is the name we want to set to a particular cell.
*/
void DataFrame::setColName(int col, char* name)
{
	colNames[col] = name;
}

/*
This method returns the row of the table given my int i. This is an overloaded method.
	@param int i Passing value from the user.
	@return int* table[i] An address with access to integer values.
*/
int* DataFrame::operator[] (int i)
{
	return table[i];
}

/*
Returns the row name.
	@return rowNames The names entered in for rows.
*/
char** DataFrame::getRowNames()
{
	return rowNames;
}

/*
Returns the column name.
	@returns colNames The names entered in for columns.
*/
char** DataFrame::getColNames()
{
	return colNames;
}

/*
Returns the row number.
	@returns noRows The number of rows in table.
*/
int DataFrame::getNumberRows()
{
	return noRows;
}

/*
Returns the column number.
	@return noCols The number of columns in table.
*/
int DataFrame::getNumberCols()
{
	return noCols;
}

/*
Making the columns with the number of columns in matrix. This method creates the whole new table.
    @param int* columns Is the column number being requested.
	@param int cLen Is the number of columns in table.
	@return tempColumn Is the object that will display columns created.
*/
DataFrame* DataFrame::getColumns(int* columns, int cLen)
{
	// Create a new DataFrame to display according to columns given.
	DataFrame* tempColumn = new DataFrame(noRows, cLen);
	
	// Setting row names into tempColumn.
	for (int i = 0; i < noRows; i++)
	{
		(*tempColumn).setRowName(i, rowNames[i]);
		// Populating the table.
		for (int j = 0; j < cLen; j++)
		{
			(*tempColumn)[i][j] = table[i][columns[j]];
		}
	}
	// Setting column names and size of column array may change.
	for (int i = 0; i < cLen; i++)
	{
		(*tempColumn).setColName(i, colNames[columns[i]]);
	}

	return tempColumn;
}

/*
Making the rows with the number of rows in maxtrix.
	@param int* rows Is the row number being requested.
	@param int rLen Is the number of rows in table.
	@return tempRow Is the object that will display rows created.
*/
DataFrame* DataFrame::getRows(int* rows, int rLen)
{
	// Create a new DataFrame to return of rows.
	DataFrame* tempRow = new DataFrame(rLen, noCols);

	// Setting row names into tempRow and size may change.
	for (int i = 0; i < rLen; i++)
	{
		(*tempRow).setRowName(i, rowNames[rows[i]]);
		// Populating the table.
		for (int j = 0; j < noCols; j++)
		{
			(*tempRow)[i][j] = table[rows[i]][j];
		}
	}
	// Setting column names into tempRow.
	for (int i = 0; i < noCols; i++)
	{
		(*tempRow).setColName(i, colNames[i]);
	}

	return tempRow;
}

/*
Making the rows and columns with the number of rows and columns.
	@param int* rows Is the row number being requested.
	@param int rLen Is the number of rows in table.
	@param int* cols Is the column number being requested.
	@param int cLen Is the number of columns in table.
	@return tempFrame It is the object that will display the table.
*/
DataFrame* DataFrame::getRowsCols(int* rows, int rLen, int* cols, int cLen)
{
	// Create a new temp DataFrame to return.
	DataFrame* tempFrame = new DataFrame(rLen, cLen);

	for (int i = 0; i < rLen; i++)
	{
		// Setting row names into tempFrame and size may change.
		(*tempFrame).setRowName(i, rowNames[rows[i]]);

		for (int j = 0; j < cLen; j++)
		{
			// Setting column names into tempFrame and size my change.
			(*tempFrame).setColName(j, colNames[cols[j]]);
			// Populate the table.
			(*tempFrame)[i][j] = table[rows[i]][cols[j]];
		}
	}

	return tempFrame;
}

/*
Deconstructor deletes the table, row and column names once the program stops to free up memory.
*/
DataFrame::~DataFrame()
{
	// If table exist then delete it.
	if (table != NULL)
	{	
		// Delete the table.
		for (int i = 0; i < noRows; i++)
		{
			delete table[i];
		}
		delete[] table;
	}
	// If colNames exist then delete it.
	if (colNames != NULL) 
	{
		//for (int i = 0; i < noCols; i++)
		//{
		//	delete colNames[i];
		//}
		delete[] colNames;
	}
	// If rowNames exist then delete it. 
	if (rowNames != NULL) 
	{
		//for (int i = 0; i < noRows; i++)
		//{
		//	delete rowNames[i];
		//}
		delete[] rowNames;
	}

}
