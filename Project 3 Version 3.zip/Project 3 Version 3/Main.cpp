/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	SortedArray<int>* test = new SortedArray<int>(10);
	(*test).insert(1);
	(*test).insert(2);
	(*test).insert(3);
	(*test).insert(4);
	(*test).insert(5);
	(*test).insert(6);
	(*test).insert(7);
	(*test).insert(8);
	(*test).insert(9);
	(*test).insert(10);
	(*test).display();

	//SortedArray<int>* test2 = new SortedArray<int>(5);
	//(*test2).insert(6);
	//(*test2).insert(7);
	//(*test2).insert(8);
	//(*test2).insert(9);
	//(*test2).insert(10);
	//(*test).join(*test2);
	//(*test).display();

	// Size limit of array.
	//int maxArraySize;
	//LinkedSortedArrays<int>* linkedArrays;

	// Read in the max array size and create the LinkedSortedArrays object.
	//cin >> maxArraySize;

	//linkedArrays = new LinkedSortedArrays<int>(maxArraySize);

	return 0;
}