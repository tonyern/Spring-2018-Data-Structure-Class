/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include "LinkedSortedArrays.h"
using namespace std;

int main()
{
	/*SortedArray<int>* test1 = new SortedArray<int>(10);
	(*test1).insert(1);
	(*test1).insert(2);
	(*test1).insert(3);
	(*test1).insert(4);
	(*test1).insert(5);
	(*test1).insert(6);
	(*test1).insert(7);
	(*test1).insert(8);
	(*test1).insert(9);
	(*test1).insert(10);
	(*test1).split(5);*/

	/*SortedArray<int>* test2 = new SortedArray<int>(5);
	(*test2).insert(8);
	(*test2).insert(3);
	(*test2).insert(1);
	(*test2).insert(0);
	(*test2).insert(69);

	(*test1).join(*test2);
	cout << (*test1).getMin() << endl;
	cout << (*test1).getMax() << endl;
	cout << (*test1).getSize() << endl;
	cout << (*test1).getNumberOfItems() << endl;
	(*test1).display();*/

	// Size limit of array.
	int maxArraySize;
	LinkedSortedArrays<int>* linkedArrays;

	// Read in the max array size and create the LinkedSortedArrays object.
	cin >> maxArraySize;

	linkedArrays = new LinkedSortedArrays<int>(maxArraySize);

	return 0;
}
