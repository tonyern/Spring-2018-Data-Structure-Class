/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "SortedArray.h"
using namespace std;

template <class DT>
class LinkedSortedArrays
{
protected:
	// LinkedList to store sorted arrays in.
	list<SortedArray<DT>> nameIT;
	// The sorted array.
	SortedArray<DT>* sortedArray;
	// Max size of array in Sorted Array.
	int ArraySizeFactor;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Overloaded constructor with max size for sorted arrays.
	LinkedSortedArrays(int arraySize);
	// Copy constructor.
	LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other);

	// Find the number.
	int find(const DT& lookFor);
	// Insert number into an array.
	int insert(const DT& newOne);
	// Remove number from an array.
	int remove(const DT& X);

	// Display the array.
	void display();
	// Get max size of array.
	int getArraySizeFactor() const;
	// Deconstructor.
	virtual ~LinkedSortedArrays();
};

/*
Default constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays()
{
	nameIT.push_back(NULL);
	sortedArray = NULL;
	ArraySizeFactor = 0;
}

/*
Overloaded constructor that determines max size for all sorted arrays.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(int arraySize)
{
	ArraySizeFactor = arraySize;

	// Pushing sorted array onto list.
	sortedArray = new SortedArray<DT>(arraySize);
	nameIT.push_back(*sortedArray);

	// Read data from file.
	char c = '0';
	// Helps convert character to integer.
	int iNum;
	for (int i = 100; i != 0; i--)
	{
		cin.get(c);
		
		switch (c)
		{
		case 'I':
			cin.get(c);
			cin.get(c);
			iNum = c - '0';
			insert(iNum);
			break;
		case 'R':
			cin.get(c);
			cin.get(c);
			iNum = c - '0';
			remove(iNum);
			break;
		case 'F':
			cin.get(c);
			cin.get(c);
			iNum = c - '0';
			find(iNum);
			break;
		case 'O':
			cin.get(c);
			display();
			break;
		}
	}
}

/*
Copy constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other)
{

}

/*
This method finds item user is looking for by iterating through the LinkedList.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
template <class DT>
int LinkedSortedArrays<DT>::find(const DT& lookFor)
{
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& sa = *iter;

		// Making sure lookFor is within bounds to execute a find.
		if ((sa.getMin() <= lookFor) && (sa.getMax() >= lookFor))
		{
			int itemIndex = sa.find(lookFor);
			// Output node and index it is located in.
			cout << i << " " << itemIndex << endl;
			return itemIndex;
		}

		// If lookFor is smaller than min or we have reached the end of node with max value of last one being smaller than lookFor.
		if ((sa.getMin() < lookFor) || iter == nameIT.end() && sa.getMax() < lookFor)
		{
			cout << "-1 -1" << endl;
			return -1;
		}
	}
}


/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
template <class DT>
int LinkedSortedArrays<DT>::insert(const DT& newOne)
{
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& temp = *iter;

		// Check to make sure element doesn't already exist in list. -1 if it doesn't and any other exists.
		if (temp.find(newOne) != -1)
		{
			return -1;
		}

		// Insert newOne into list.
		int result = temp.insert(newOne);

		// Display node and index located we just inserted into.
		if (result != -1)
		{
			cout << i << " " << result << endl;
		}

		// If the element doesn't exist in list and there is no space then we have to split the array.
		if (result == -1)
		{
			nameIT.push_back(*temp.split(ArraySizeFactor / 2));
		}
	}
}

/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
template <class DT>
int LinkedSortedArrays<DT>::remove(const DT& X)
{
	// Loop through all nodes available.
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& temp = *iter;

		// Check if the number exists.
		if (temp.find(X) != -1)
		{
			int numberOfItems = temp.remove(X);
			// Output node and how many items remain after removing one.
			cout << i << " " << numberOfItems;
			return numberOfItems;
		}
		else
		{
			// If it doesn't exist then output -1 -1.
			cout << "-1 -1" << endl;
		}
	}
}

/*
Display the sorted array.
*/
template <class DT>
void LinkedSortedArrays<DT>::display()
{
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++)
	{
		SortedArray<DT>& temp = *iter;
		temp.display();
	}
}

/*
Get the max size of array.
@return ArraySizeFactor
*/
template <class DT>
int LinkedSortedArrays<DT>::getArraySizeFactor() const
{
	return ArraySizeFactor;
}

/*
Deconstructor.
*/
template <class DT>
LinkedSortedArrays<DT>::~LinkedSortedArrays()
{
	if (sortedArray != NULL)
	{
		sortedArray = NULL;
		delete sortedArray;
	}

	nameIT.clear();
	nameIT.~list();
	ArraySizeFactor = 0;
}