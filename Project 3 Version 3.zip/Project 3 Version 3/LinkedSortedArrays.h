/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "SortedArray.h"
using namespace std;

template <class DT>
class LinkedSortedArrays
{
protected:
	// LinkedList to store sorted arrays in.
	list<SortedArray<DT>> nameIT;
	// The sorted array.
	SortedArray<DT>* sortedArray;
	// Max size of array in Sorted Array.
	int ArraySizeFactor;
	// Number of nodes in list.
	int length;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Overloaded constructor with max size for sorted arrays.
	LinkedSortedArrays(int arraySize);
	// Copy constructor.
	LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other);

	// Find the number.
	int find(const DT& lookFor);
	// Insert number into an array.
	int insert(const DT& newOne);
	// Remove number from an array.
	int remove(const DT& X);

	// Display the array.
	void display();
	// Get max size of array.
	int getArraySizeFactor() const;
	// Get number of nodes in list.
	int getLength();
	// Deconstructor.
	virtual ~LinkedSortedArrays();
};

/*
Default constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays()
{
	nameIT.push_back(NULL);
	sortedArray = NULL;
	ArraySizeFactor = 0;
	length = 0;
}

/*
Overloaded constructor that determines max size for all sorted arrays.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(int arraySize)
{
	ArraySizeFactor = arraySize;
	length = 0;
	// Pushing sorted array onto list.
	sortedArray = new SortedArray<DT>(arraySize);
	nameIT.push_back(*sortedArray);

	// Read data from file.
	char c = '0';
	// Column index for data.
	int j = 0;
	// Temp array to hold.
	char** data;
	data = new char*[100];
	for (int i = 0; i < 100; i++)
	{
		data[i] = new char[100];
	}
	// Read in input.
	for (int i = 0; i != 100; i++)
	{
		cin.get(c);
		
		switch (c)
		{
		case 'I':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			insert(atoi(data[i]));
			break;
		case 'R':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			remove(atoi(data[i]));
			break;
		case 'F':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			find(atoi(data[i]));
			break;
		case 'O':
			cin.get(c);
			display();
			break;
		}
	}
}

/*
Copy constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other)
{

}

/*
This method finds item user is looking for by iterating through the LinkedList.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
template <class DT>
int LinkedSortedArrays<DT>::find(const DT& lookFor)
{
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& sa = *iter;

		// Making sure lookFor is within bounds to execute a find.
		if (sa.getMin() <= lookFor && sa.getMax() >= lookFor)
		{
			int itemIndex = sa.find(lookFor);
			if (itemIndex == -1)
			{
				cout << "-1 -1" << endl;
				return -1;
			}
			// Output node and index it is located in.
			cout << i << " " << itemIndex << endl;
			return itemIndex;
		}
		// If lookFor is less than the min or we have reached the end of list then return -1.
		else if (sa.getMin() > lookFor || i == length)
		{
			return -1;
		}
		// Else the element doesn't exist in any node then output -1 -1. 
		else
		{
			cout << "-1 -1" << endl;
			return -1;
		}

		// Do nothing and move on to next node if lookFor is greater than the max.
	}
}

/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
template <class DT>
int LinkedSortedArrays<DT>::insert(const DT& newOne)
{
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& temp = *iter;

		// Check to make sure element doesn't already exist in list. If it exist then return index it is located at.
		int indexFind = temp.find(newOne);
		if (indexFind != -1)
		{
			return indexFind;
		}

		// Insert newOne into list.
		int result = temp.insert(newOne);

		/*// Check if we can merge the two arrays.
		auto it1 = nameIT.begin();
		auto it2 = nameIT.begin();
		advance(it1, nameIT.size() - 1);
		advance(it2, nameIT.size() - 2);

		for (int i = 0; i < ArraySizeFactor; i++)
		{
			if ((*it1.size() + *it2.size()) == ArraySizeFactor)
			{
				(*it2).join(*it1);
			}
		}
		it1--;
		it2--;*/

		// Display node and index located we just inserted into.
		if (result != -1)
		{
			cout << i << " " << result << endl;
		}

		// If the element doesn't exist in list and there is no space then we have to split the array.
		if (result == -1 && indexFind == -1)
		{
			SortedArray<DT>* splitTemp = temp.split(ArraySizeFactor / 2);
			nameIT.push_back(*splitTemp);
			// Increase length because we created a new node.
			length++;
		}
	}
}

/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
template <class DT>
int LinkedSortedArrays<DT>::remove(const DT& X)
{
	// Loop through all nodes available.
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& temp = *iter;

		// Check if the number exists.
		if (temp.find(X) != -1)
		{
			int numberOfItems = temp.remove(X);
			// Output node and how many items remain after removing one.
			cout << i << " " << numberOfItems;
			return numberOfItems;
		}
		else if (i == length)
		{
			// If it doesn't exist in any array then output -1 -1.
			cout << "-1 -1" << endl;
		}
	}
}

/*
Display the sorted array.
*/
template <class DT>
void LinkedSortedArrays<DT>::display()
{
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++)
	{
		SortedArray<DT>& temp = *iter;
		temp.display();
	}
	cout << endl;
}

/*
Get the max size of array.
@return ArraySizeFactor
*/
template <class DT>
int LinkedSortedArrays<DT>::getArraySizeFactor() const
{
	return ArraySizeFactor;
}

/*
Get number of nodes in list.
@return length.
*/
template <class DT>
int LinkedSortedArrays<DT>::getLength()
{
	return length;
}

/*
Deconstructor.
*/
template <class DT>
LinkedSortedArrays<DT>::~LinkedSortedArrays()
{
	if (sortedArray != NULL)
	{
		sortedArray = NULL;
		delete sortedArray;
	}

	nameIT.clear();
	nameIT.~list();
	ArraySizeFactor = 0;
}