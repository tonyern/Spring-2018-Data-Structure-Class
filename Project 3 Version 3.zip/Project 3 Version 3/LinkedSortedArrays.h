/*
LinkedSortedArrays.h
Class definition for LinkedSortedArrays.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "SortedArray.h"
using namespace std;

template <class DT>
class LinkedSortedArrays
{
protected:
	// LinkedList to store sorted arrays in.
	list<SortedArray<DT>> nameIT;
	// The sorted array.
	SortedArray<DT>* sortedArray;
	// Max size of array in Sorted Array.
	int ArraySizeFactor;
	// Number of nodes in list.
	int length;
public:
	// Default constructor.
	LinkedSortedArrays();
	// Overloaded constructor with max size for sorted arrays.
	LinkedSortedArrays(int arraySize);
	// Copy constructor.
	LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other);

	// Find the number.
	int find(const DT& lookFor);
	// Insert number into an array.
	int insert(const DT& newOne);
	// Remove number from an array.
	int remove(const DT& X);

	// Display the array.
	void display();
	// Get max size of array.
	int getArraySizeFactor() const;
	// Get number of nodes in list.
	int getLength();
	// Deconstructor.
	virtual ~LinkedSortedArrays();
};

/*
Default constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays()
{
	nameIT.push_back(NULL);
	sortedArray = NULL;
	ArraySizeFactor = 0;
	length = 0;
}

/*
Overloaded constructor that determines max size for all sorted arrays.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(int arraySize)
{
	ArraySizeFactor = arraySize;
	length = 0;
	// Pushing sorted array onto list.
	sortedArray = new SortedArray<DT>(arraySize);
	nameIT.push_front(*sortedArray);

	// Read data from file.
	char c = '0';
	// Column index for data.
	int j = 0;
	// Temp array to hold.
	char** data;
	data = new char*[100];
	for (int i = 0; i < 100; i++)
	{
		data[i] = new char[100];
	}
	// Read in input.
	for (int i = 0; i != 100; i++)
	{
		cin.get(c);
		
		switch (c)
		{
		case 'I':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			insert(atoi(data[i]));
			break;
		case 'R':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			remove(atoi(data[i]));
			break;
		case 'F':
			j = 0;
			cin.get(c);
			do
			{
				cin.get(c);
				data[i][j++] = c;
			} while (c != '\n');

			data[i][j] = '\0';
			find(atoi(data[i]));
			break;
		case 'O':
			cin.get(c);
			display();
			break;
		}
	}
}

/*
Copy constructor.
*/
template <class DT>
LinkedSortedArrays<DT>::LinkedSortedArrays(const LinkedSortedArrays<SortedArray<DT>>& other)
{

}

/*
This method finds item user is looking for by iterating through the LinkedList.
@param lookFor Item we are looking for.
@return int The item's index we are looking for.
*/
template <class DT>
int LinkedSortedArrays<DT>::find(const DT& lookFor)
{
	// If there is nothing in nameIT then return -1.
	if (nameIT.empty())
	{
		cout << "-1 -1" << endl;
		return -1;
	}

	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& sa = *iter;

		// Making sure lookFor is within bounds to execute a find.
		if (sa.getMax() >= lookFor)
		{
			int itemIndex;
			if (sa.getMin() <= lookFor)
			{
				itemIndex = sa.find(lookFor);

				// Can't find number in that node then break out and move on to next node.
				if (itemIndex == -1)
				{
					break;
				}

				// Output node and index it is located in and return location index.
				cout << i << " " << itemIndex << endl;
				return itemIndex;
			}
			// If the min is greater than lookFor or we reach the end but lookFor is still bigger than the max then return -1.
			else if (sa.getMin() > lookFor || i == length)
			{
				cout << "-1 -1" << endl;
				return -1;
			}
			// Else if no number has been inserted into array.
			else
			{
				cout << "-1 -1" << endl;
				return -1;
			}
		}
	}
}

/*
Inserting an array into list.
@param newOne The array we are inserting.
@return int Index.
*/
template <class DT>
int LinkedSortedArrays<DT>::insert(const DT& newOne)
{
	// Make sure nameIT is not empty.
	if (nameIT.empty()) 
	{
		nameIT.emplace_front(ArraySizeFactor);
	}

	auto it = nameIT.begin();
	it++;
	int ix = 0;
	for (; it != nameIT.end() && !(it->getMin() > newOne); it++, ix++);
	it--;

	int ans = (*it).insert(newOne);
	if (ans == -1) 
	{
		auto it2 = it;
		it2++;
		{
			SortedArray<DT>& x = (*it).split(ArraySizeFactor / 2);
			it2 = nameIT.insert(it2, x);
		}

		if (it2->getMin() > newOne) 
		{
			ans = (*it).insert(newOne);
		}
		else 
		{
			ans = (*it2).insert(newOne);
			ix++;
		}

		// Join the two arrays if we can.
		auto it3 = it2;
		it3++;
		if (it3 != nameIT.end() && it3->getSize() + it2->getSize() <= ArraySizeFactor) 
		{
			(*it2).join(*it3);
			nameIT.erase(it3);
		}

		// Join the two arrays if we can.
		if (it != nameIT.begin()) 
		{
			it2 = it;
			it2--;
			if (it2->getSize() + it->getSize() <= ArraySizeFactor) 
			{
				(*it2).join(*it);
				nameIT.erase(it);
			}
		}
	}

	// Output node and index item is located in.
	cout << ix << " " << ans << endl;
	return ans;
}

/*
Remove an element from the list.
@param X The element to be removed.
@return Value removed.
*/
template <class DT>
int LinkedSortedArrays<DT>::remove(const DT& X)
{
	// Making sure nameIT is not empty.
	if (nameIT.empty())
	{
		cout << "-1 -1" << endl;
		return -1;
	}

	// Loop through all nodes available.
	int i = 0;
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++, i++)
	{
		SortedArray<DT>& temp = *iter;

		// Check if the number exists.
		if (temp.find(X) != -1)
		{
			int numberOfItems = temp.remove(X);

			// Check if we can join any arrays.


			// Output node and how many items remain after removing one.
			cout << i << " " << numberOfItems;
			return numberOfItems;
		}
		else if (i == length)
		{
			// If it doesn't exist in any array then output -1 -1.
			cout << "-1 -1" << endl;
			return -1;
		}
	}
}

/*
Display the sorted array.
*/
template <class DT>
void LinkedSortedArrays<DT>::display()
{
	for (auto iter = nameIT.begin(); iter != nameIT.end(); iter++)
	{
		SortedArray<DT>& temp = *iter;
		temp.display();
	}
	cout << endl;
}

/*
Get the max size of array.
@return ArraySizeFactor
*/
template <class DT>
int LinkedSortedArrays<DT>::getArraySizeFactor() const
{
	return ArraySizeFactor;
}

/*
Get number of nodes in list.
@return length.
*/
template <class DT>
int LinkedSortedArrays<DT>::getLength()
{
	return length;
}

/*
Deconstructor.
*/
template <class DT>
LinkedSortedArrays<DT>::~LinkedSortedArrays()
{
	if (sortedArray != NULL)
	{
		sortedArray = NULL;
		delete sortedArray;
	}

	nameIT.clear();
	nameIT.~list();
	ArraySizeFactor = 0;
	length = 0;
}