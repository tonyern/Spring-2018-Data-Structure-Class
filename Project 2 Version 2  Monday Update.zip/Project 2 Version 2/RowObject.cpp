/*
RowObject.cpp
This class gets data from leading cause of death in the US.
Arthor: Tony Nguyen
Date Created: 2/11/2018
Version: 1.0
*/

#include <iostream>
#include "RowObject.h"
using namespace std;

/*
Default constructor that creates an empty row object because it wasn't given any info.
*/
RowObject::RowObject()
{
	int ID = 0;
	int year = 0;
	causeName = NULL;
	state = NULL;
	numberOfDeaths = 0;
	averageAge = 0;
}

/*
Overloaded constructor that creates the row object given the info passed in.
@param int rid ID That is row number.
@param int y Year.
@param const char* cn Cause of Death.
@param const char* s State in the United States.
@param int n Number of Deaths.
@param float age Average age of Deaths.
*/
RowObject::RowObject(int rid, int y, const char* cn, const char* s, int n, float age)
{
	ID = rid;
	year = y;

	// Counting how long cn is.
	const char* causeHolder = cn;
	int length = 0;
	while (*causeHolder++ != '\0')
	{
		length++;
	}
	// Creating causeName and setting cn to it.
	causeName = new char[length];
	for (int i = 0; i < length; i++)
	{
		causeName[i] = cn[i];
	}
	// Adding null character at the end of causeName to prevent garbage.
	causeName[length] = '\0';
	
	// Counting how long s is.
	const char* stateHolder = s;
	length = 0;
	while (*stateHolder++ != '\0')
	{
		length++;
	}
	// Creating state and setting s to it.
	state = new char[length];
	for (int i = 0; i < length; i++)
	{
		state[i] = s[i];
	}
	// Adding null character at the end of state to prevent garbage.
	state[length] = '\0';

	numberOfDeaths = n;
	averageAge = age;

	//cout << ID << "," << year << "," << causeName << "," << state << "," << numberOfDeaths << "," << averageAge <<endl;
}

/*
Write the ostream operator. For displaying the object's content.
@param ostream &output The object's content in format.
@param RowObject &row The row object to display.
@return output The address for row object to display.
*/
ostream& operator<< (ostream& output, const RowObject& row)
{
	output << row.ID << "," << row.year << "," << row.causeName << "," << row.state << "," << row.numberOfDeaths << "," << row.averageAge;
	return output;
}

/*
Deconstructor that frees up memory after running the program.
*/
RowObject::~RowObject()
{
	if (causeName != NULL)
	{
		causeName = NULL;
		delete[] causeName;
	}
	if (state != NULL)
	{
		state = NULL;
		delete[] state;
	}
	ID = 0;
	year = 0;
	numberOfDeaths = 0;
	averageAge = 0;
}
