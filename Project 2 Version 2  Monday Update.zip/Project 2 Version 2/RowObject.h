/*
RowObject.h
This class gets data from leading cause of death in the US.
Arthor: Tony Nguyen
Date Created: 2/11/2018
Version: 1.0
*/

#include<iostream>
using namespace std;

class RowObject
{
	// Ostream operator. This helps display the contents of the row object.
	friend ostream& operator<< (ostream& output, const RowObject& row);
protected:
	int ID;
	int year;
	char* causeName;
	char* state;
	int numberOfDeaths;
	float averageAge;
public:
	// Default constructor.
	RowObject();
	// Overloaded constructor that takes in info to make the row object.
	RowObject(int rid, int y, const char* cn, const char* s, int n, float age);
	// Deconstructor.
	~RowObject();
};
