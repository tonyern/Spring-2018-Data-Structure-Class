/*
Main.cpp
Class that runs the program.
Created by: Tony Nguyen
Date Created: 2/28/2018
Version: 1.0
*/

#include <iostream>
#include <list>
#include "LinkedSortedArrays.h"
#include "SortedArray.h"
using namespace std;

int main()
{
	// Testing third constructor.
	SortedArray<int>* testSortedArray2 = new SortedArray<int>(5);
	(*testSortedArray2)[0] = 5;
	(*testSortedArray2)[1] = 9;
	(*testSortedArray2)[2] = 10;
	(*testSortedArray2)[3] = 15;
	(*testSortedArray2)[4] = 69;

	SortedArray<int>* testSortedArray3 = new SortedArray<int>(5);
	(*testSortedArray3)[0] = 1;
	(*testSortedArray3)[1] = 3;
	(*testSortedArray3)[2] = 12;
	(*testSortedArray3)[3] = 16;
	(*testSortedArray3)[4] = 51;

	(*testSortedArray2).join(*testSortedArray3);

	return 0;
}
