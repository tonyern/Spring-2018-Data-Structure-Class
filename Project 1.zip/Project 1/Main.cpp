/*
This the main function that starts everything in the program.
	Created on: 1/22/2018
	Author: Tony Nguyen
	Version: 1.0
*/
#include <iostream>
#include "DataFrame.h"
using namespace std;

int main()
{
	// Rows and columns that will determine table size.
	int column;
	int row;

	// 3 X 10 matrix of rows and columns with integer values that store inputs for configuring table.
	int selectColumn[3];
	int selectRow[10];

	// Taking in the rows and columns.
	cin >> row >> column;
	
	// Creating the dataframe given the row and column the user inputted.
	DataFrame* firstDF = new DataFrame(row, column);
	
	// Array of characters to store first character of every word after blackspace and comma.
	char** colNames;
	// J Index to add stuff to column pointer.
	int j = 0;
	// Character holder that holds the characters from the strings of characters.
	char c;
	// Creates new arrays from pointer arrays taking in column size.
	colNames = new char*[column];
	// Creating the column in column names.
	for (int i = 0; i < column; i++) 
	{
		// Set to size 100 just in case of a large character input to account for.
		colNames[i] = new char[100];
	}
	// Start reading stuff.
	for (int i = 0; i < column; i++) 
	{
		// Reads the first character.
		cin.get(c);
		
		// Resets the j index.
		j = 0;
		do
		{
			// Adding characters to the array until we hit a comma or \0.
			colNames[i][j++] = c;
			// Read next character until we hit \0 or comma.
			cin.get(c);

		} while ((c != ',') && (c != '\n'));

		// Set the comma thing to null.
		colNames[i][j] = '\0';
		// Putting name splitted into column.
		(*firstDF).setColName(i, colNames[i]);
	}

	// Array of characters to store first character of every word after blackspace and comma.
	char** rowNames;
	// J Index.
	j = 0;
	// Character holder.
	char r;
	// Creates new arrays from pointer arrays.
	rowNames = new char*[row];
	// Looping through to the whole string of characters until we hit '\0'.
	for (int i = 0; i < row; i++)
	{
		// Set to size 100 just in case of a large character input to account for.
		rowNames[i] = new char[100];
	}
	// Start reading stuff.
	for (int i = 0; i < row; i++)
	{
		// Reads the first character.
		cin.get(r);
		// Resets the j index.
		j = 0;
		do
		{
			// Adding characters to the array until we hit a comma or \0.
			rowNames[i][j++] = r;
			// Read next character until we hit \0 or comma.
			cin.get(r);

		} while ((r != ',') && (r != '\n'));

		// Set the comma thing to null.
		rowNames[i][j] = '\0';
		// Putting name splitted into column.
		(*firstDF).setRowName(i, rowNames[i]);
	}

	// Initializing table with integer values.
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < column; j++)
		{
			cin >> (*firstDF)[i][j];
		}
	}

	// Displays the table.
	(*firstDF).display();

	// Read the column names that you want to extract to display.
	for (int i = 0; i < 3; i++)
	{
		cin >> selectColumn[i];
	}

	// Get the chosen columns and display new table with what was given.
	DataFrame* tempColumns = (*firstDF).getColumns(selectColumn, 3);
	(*tempColumns).display();

	// Change the row names of select rows and display.
	(*tempColumns).setRowName(2, (char*) "Jack");
	(*tempColumns).setRowName(3, (char*) "Peter");
	(*tempColumns).display();

	// Read the row names that you want to extract to display.
	for (int i = 0; i < 10; i++)
	{
		cin >> selectRow[i];
	}

	// Make the rows and display it.
	DataFrame* tempRows = (*firstDF).getRows(selectRow, 10);
	(*tempRows).display();

	// Change the column names of selected columns and display.
	(*tempRows).setColName(2, (char*) "Scores");
	(*tempRows).setColName(3, (char*) "Values");
	(*tempRows).display();

	// Extract the rows in SelectRow and columns in SelectColumn and display.
	DataFrame* tempColsRows = (*firstDF).getRowsCols(selectRow, 10, selectColumn, 3);
	(*tempColsRows).display();

	// Delete stuff to free up memory.
	delete tempRows;
	delete tempColumns;
	delete tempColsRows;

	// Sample code to execute. We have to execute this.
	DataFrame* myTable = new DataFrame(5, 5);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			(*myTable)[i][j] = i * j;
		}
	}

	// Display the 5 by 5 table.
	(*myTable).display();

	// Delete the table to free up memory.
	delete myTable;
	
	return 0;
}