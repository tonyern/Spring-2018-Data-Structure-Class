/*
Main.cpp
This is the main method that runs the program.
Arthor: Tony Nguyen
Date Created: 2/12/2018
Version: 1.1
*/

#include <iostream>
#include "RowObject.h"
#include "DataFrame.h"
using namespace std;

int main()
{	
	// Rows for the matrix.
	int noRows;
	int noCols;
	DataFrame<RowObject>* DBT;

	// Selects specified rows to display.
	int selectR[10];

	for (int i = 0; i < 10; i++)
	{
		selectR[i] = i + 2;
	}
	
	// Reading in number of rows and there are 5 columns to create the DataFrame.
	cin >> noRows;
	noCols = 5;
	DBT = new DataFrame<RowObject>(noRows, noCols);

	// Array of characters to store first character of every word after blackspace and comma.
	char** colNames;
	// J Index to add stuff to column pointer.
	int j = 0;
	// Character holder that holds the characters from the strings of characters.
	char c = NULL;
	// Creates new arrays from pointer arrays taking in column size.
	colNames = new char*[noCols];
	// Creating the column in column names.
	for (int i = 0; i < noCols; i++)
	{
		// Set to size 100 just in case of a large character input to account for.
		colNames[i] = new char[100];
	}
	// Start reading stuff.
	for (int i = 0; i < noCols; i++)
	{
		// Reads the first character.
		cin.get(c);

		// Resets the j index.
		j = 0;
		do
		{
			// Adding characters to the array until we hit a comma or \0.
			colNames[i][j++] = c;
			// Read next character until we hit \0 or comma.
			cin.get(c);

		} while ((c != ',') && (c != '\n'));

		// Set the comma thing to null.
		colNames[i][j] = '\0';
		// Putting name splitted into column.
		(*DBT).setColName(i, colNames[i]);
	}

	// Array of row objects to read in.
	RowObject** rows;
	// Array for temp values.
	char** tempValues;
	// J index.
	int jIndex = 0;
	// Character holder.
	char charHolder = NULL;
	tempValues = new char*[6];
	for (int i = 0; i < 6; i++)
	{
		tempValues[i] = new char[100];
	}
	// Create new arrays with pointer arrays.
	rows = new RowObject*[noRows];
	// Create empty row objects for each index.
	for (int i = 0; i < noRows; i++)
	{
		rows[i] = new RowObject();
	}
	// Start reading stuff.
	for (int i = 0; i < noRows; i++)
	{
		// Read the first character.
		cin.get(charHolder);
		// Resets the j index.
		jIndex = 0;
		do
		{
			// Adding characters to the array until we hit a comma.
			tempValues[i][j++] = charHolder;
			// Read next character until we hit comma.
			cin.get(charHolder);

		} while (charHolder != ',');

		tempValues[i][j] = '\0';
		int tempYear = (int) tempValues[i];

		// Read the first character.
		cin.get(charHolder);
		// Resets the j index.
		i++;
		jIndex = 0;
		do
		{
			// Adding characters to the array until we hit a comma.
			tempValues[i][j++] = charHolder;
			// Read next character until we hit comma.
			cin.get(charHolder);

		} while (charHolder != ',');

		tempValues[i][j] = '\0';
	}

	/*/////////////////////////////////////
	// Read the input; store the row number for each row read in ID.
	RowObject* newRow = new RowObject(1, 2018, "Shot Dead", "Illinois", 54, 12.8);
	RowObject* newRow1 = new RowObject(2, 2019, "Knifed", "Oklahoma", 54, 12.8);
	RowObject* newRow2 = new RowObject(3, 2020, "Mugged", "New York", 54, 12.8);
	RowObject* newRow3 = new RowObject(4, 2021, "Suicide", "Japan", 54, 12.8);
	RowObject* newRow4 = new RowObject(69, 6060, "Raped", "Sweden", 69, 17.8);
	(*DBT).insertRow(0, *newRow);
	(*DBT).insertRow(1, *newRow1);
	(*DBT).insertRow(2, *newRow2);
	(*DBT).insertRow(3, *newRow3);
	(*DBT).addRow(*newRow);
	(*DBT).addRow(*newRow1);
	(*DBT).addRow(*newRow2);
	(*DBT).addRow(*newRow3);
	(*DBT).display();
	/////////////////////////////////////*/

	// Change the column names of selected columns.
	(*DBT).setColName(4, "Number Deaths");
	(*DBT).setColName(2, "Cause Name");
	(*DBT).display();
	
	/*// Extract the rows in SelectR to display.
	DataFrame<RowObject>* tempRows = (*DBT).getRows(selectR, 10);
	(*tempRows).display();
	
	// Testing [] operator on DataFrame object and ostream on RowObject.
	cout << (*DBT)[4];
	cout << (*DBT)[5];
	cout << (*DBT)[10];
	
	// Testing addRow, constructor for RowObject and getNumberRows method.
	RowObject* newRow;      
	newRow = new RowObject((*DBT).getNumberRows(),2018,"Cancer","Oklahoma",200, 58.2);
	(*DBT).addRow(*newRow);
	// Testing destructor for RowObject.
	delete newRow;

	newRow = new RowObject((*DBT).getNumberRows(),2018,"Opiod","Texas",2000, 32.4);
	(*DBT).addRow(*newRow);
	delete newRow;
	
	cout << (*DBT)[(*DBT).getNumberRows()-2];
	cout << (*DBT)[(*DBT).getNumberRows()-1];
	
	// Testing insertRow.
	newRow = new RowObject((*DBT).getNumberRows(),2016,"Cancer","Texas",500, 72.1);
	(*DBT).insertRow(1, *newRow);
	delete newRow;

	newRow = new RowObject((*DBT).getNumberRows(),2016,"Stroke","Oklahoma",400, 68.1);
	(*DBT).insertRow(4, *newRow);
	delete newRow;

	(*DBT).display(10);

	// Testing removeRow.
	(*DBT).removeRow(1);
	(*DBT).removeRow(3);
	(*DBT).display(10);*/

	return 0;
}